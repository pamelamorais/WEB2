
from app import db

class Resource(db.Model):
    id = db.Column(db.Integer, primary_key=True, nullable=False)
    action_id= db.Column(db.Integer, db.ForeignKey('action.id'), nullable=False, unique=True)
    controller_id = db.Column(db.Integer, db.ForeignKey('controller.id'), nullable=False, unique=True)
    resources = db.relationship('Privilege', backref = 'resource')

    def __repr__(self):
        return '<Resource %r>' % self.id
    
    def to_dict(self):
        return{
            "id": self.id,
            "action_id": self.action_id,
            "controller_id":self.controller_id,
            "resources": self.resources
        }