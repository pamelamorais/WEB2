import imp
from urllib.parse import uses_relative
from app import app
from flask import jsonify
from flask import request
from app import User
from werkzeug.security import check_password_hash, generate_password_hash
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required
import jwt

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    if "email" not in data or data["email"] is None:
        return jsonify({"error": True, "message": " email não informado."}), 400
    if "password" not in data or data["password"] is None:
        return jsonify({"error": True, "message": " senha do user não informada."}), 400
    
    user = User.query.filter_by(email = data ["email"]).first()

    if not user:
        return jsonify("O email solicitado não foi encontrado"),401
    
    senha = generate_password_hash(data["password"])

    if check_password_hash(senha, user.password):
        access_token = create_access_token(identity=user.id)
        return jsonify(access_token = access_token)

    return jsonify({"error": True, "message": "Informação errada."})

@app.route("/msg", methods=["GET"])
@jwt_required()
def me():
    current_identify = get_jwt_identity()
    return jsonify({"message": current_identify, "message":"logado com sucesso"}), 200

@app.route("/protected", methods=["GET"])
@jwt_required(optional=True)
def protected():
    current_identify = get_jwt_identity()
    if current_identify:
        return jsonify(logged_in_as=current_identify)
    else:
        return jsonify(logged_in_as="usuario anonimo")