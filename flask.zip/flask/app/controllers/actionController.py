from app import app, db
from app import Action
from flask import request, jsonify


@app.route("/action/add", methods=["POST"])
def action_add():
    data = request.get_json()
    if "name" not in data or data["name"] is None:
        return jsonify({"error": True, "message": "O dado solicitado não foi informado."}), 400

    action = Action(name=data["name"])
    
    try:
        db.session.add(action)
        db.session.commit()

        return jsonify({"error": False})
    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Algumas das informações solicitadas não foram informadas"}), 400

@app.route("/action/edit/<int:id>", methods=["PUT"])
def action_edit(id):
    action = Action.query.get(id)

    if action == None:
        return jsonify ({"message":"Nao é possivel editar. ", "error": True})

    data = request.get_json()
    action.name = data["name"]

    try:
        db.session.commit()

        return jsonify ({ "message":"Informações editadas com sucesso"}), 200

    except:
        db.session.rollback()
        return jsonify ({"error":True, "message":"Erro ao editar"}), 200

@app.route("/action/delete/<int:id>", methods=["DELETE"])
def action_delete(id):
    action = Action.query.get(id)

    if action == None:
        return jsonify ({"message":"Informação não informada.", "error": True})
    
    db.session.delete(action)

    try:
        db.session.commit()

        return jsonify ({"error":False, "message":"Informação deletada com sucesso"}), 200

    except:
        db.session.rollback()
        return jsonify ({"error":True, "message":"Erro ao deletar"}), 200

@app.route("/action/view/<int:id>", methods=["GET"])
def action_view(id):
    action = Action.query.get(id)

    if action == None:
        return jsonify({"message": "Informação não registrada.", "error":True})

    return jsonify({
        "data": action.to_dict(),
        "error": False
    })

@app.route("/action/list", methods=["GET"])
def action_list():
    actions = Action.query.all()
    arr = []

    for action in actions:
        arr.append(action.to_dict())

    return jsonify({"elements":arr, "error":False})