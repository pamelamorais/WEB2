import resource
from app import app, db
from app import Resource
from flask import request, jsonify

@app.route("/resource/add", methods=["POST"])
def resource_add():
    data = request.get_json()

    if "action_id" not in data or data["action_id"] is None:
        return jsonify({"error": True, "message": "O action_id não foi informado"}), 400
    if "controller_id" not in data or data["controller_id"] is None:
        return jsonify({"error": True, "message": "Não existe."}), 400

    resource = Resource(action_id=data["action_id"],controller_id=data["controller_id"])

    try:
        db.session.add(resource)
        db.session.commit()

        return jsonify({"error": False})

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Alguma das informações necessárias não foram informadas"}), 400 
    
@app.route("/resource/edit/<int:id>", methods=["PUT"])
def resource_edit(id):
    resource = Resource.query.get(id)

    if resource == None:
        return jsonify({"message": "O usuario mencionado nao existe.", "error": True})
    
    data = request.get_json()
    resource.password = data["action_id"]
    resource.role_id = data["controller_id"]

    try:
        db.session.commit()

        return jsonify({"error": False, "message":"Informações do user foram atualizadas com sucesso."}), 200 

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Erro detectado ao atualizar as informações do user."}), 200 


@app.route("/resource/view/<int:id>", methods=["GET"])
def resource_view(id):
    user = Resource.query.get(id)

    if user == None:
        return jsonify({"message": "Dado mencionado não existe.", "error": True})

    return jsonify({
        "data": resource.to_dict(),
        "error": False
    })
    
@app.route("/resource/delete/<int:id>", methods=["DELETE"])
def resource_delete(id):
    resource = Resource.query.get(id)


    if resource == None:
        return jsonify({"message": "O usuario nao existe", "error": True})
    
    db.session.delete(resource)

    try:
        db.session.delete(resource)
        db.session.commit()

        return jsonify({"error": False, "message": "Informações do user foram deletadas com sucesso."}), 200 

    except:
        db.session.rollback()
        return jsonify({"error": True, "message": "Erro detectado ao deletar usuario"}), 200 
    
@app.route("/resource/list", methods=["GET"])
def resource_list():
    resources = Resource.query.all() 
    arr = []

    for resource in resources: 
        arr.append(resource.to_dict())

    return jsonify({"elements":arr, "error": False})