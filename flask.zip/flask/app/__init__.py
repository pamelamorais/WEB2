from flask import Flask
from flask_script import Manager, Server
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate, MigrateCommand
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, JWTManager
import jwt

app = Flask(__name__)

app.config.from_object('config')
db = SQLAlchemy(app)
migrate = Migrate(app, db)
manager = Manager(app)

app.config['SECRET_KEY'] = "Pamela1"
jwt = JWTManager(app)

manager = Manager(app) 

host = app.config["FLASK_HOST"]
port = app.config["FLASK_PORT"]
server = Server(host= host, port=port)
manager.add_command("runserver", server)
manager.add_command("db", MigrateCommand)

from app.models.roleModel import Role
from app.models.userModel import User
from app.models.resourceModel import Resource
from app.models.privilegeModel import Privilege
from app.models.controllerModel import Controller
from app.models.actionModel import Action


from app.controllers.roleController import Role
from app.controllers.userController import User
from app.controllers.controllerController import Controller
from app.controllers.actionController import Action
from app.controllers.resourceController import Resource
from app.controllers.privilegeController import Privilege
from app.controllers import autenticController
