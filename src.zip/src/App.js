import './App.css';
import Login from './components/tela';
import React from 'react';
import {Route, BrowserRouter as Router, Routes} from 'react-router-dom';
import Adicionar from './components/user';

function App() {
  return (
    <Router>
    <Routes>
      <Route path='/tela' element={<Login/>} />
      <Route path='/user/add' element={<Adicionar/>}/>
    </Routes>
    </Router>
  );
}

export default App;