import React from "react"
import './tela.css'
import axios from 'axios';

class Adicionar extends React.Component {
    constructor(props) {
      super(props);
      this.state = {      email: '',
       password: ""    };
      this.handleChangePassword = this.handleChangePassword.bind(this);
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {    this.setState({email: event.target.value});  }
    handleChangePassword(event){ this.setState({password: event.target.password}); }
    handleSubmit(event) {
      debugger
      event.preventDefault();
      axios.post('http://localhost:5000/user/add', this.state)
      .then(function (response){
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
      alert('Usuário cadastrado com sucesso: ' + this.state.value);
      event.preventDefault();
    }
  
  render() {
    return (
      <form onSubmit={this.handleSubmit} method='post'> <label className="palavra">
          <h1 className="jimin"> Adicionar Usuário</h1>
      Email:
      <input type="text" className="pokemon" value={this.state.value} onChange={this.handleChange} /> </label> 
      <label className="palavra">
      Senha:
      <input type="password" className="pokemon" value={this.state.password} onChange={this.handleChangePassword} /> 
      </label>

      <input type="submit" className="digimon" value="Cadastrar" />
      </form>
    );
  }
}

 
export {Adicionar};

