import React from "react"
import './tela.css'

class Login extends React.Component {
    constructor(props) {
      super(props);
      this.state = {      value: '',
       password: ""    };
      this.handleChangePassword = this.handleChangePassword.bind(this);
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {    this.setState({value: event.target.value});  }
    handleChangePassword(event){ this.setState({password: event.target.password}); }
    handleSubmit(event) {
      alert('Usuario cadastrado com sucesso: ' + this.state.value);
      event.preventDefault();
    }
  
    render() {
      return (
        <form onSubmit={this.handleSubmit}> <label className="palavra">
            <h1 className="jimin"> Login do Usuario</h1>
        Email:
        <input type="text" className="pokemon" value={this.state.value} onChange={this.handleChange} /> </label> 
        <label className="palavra">
        Senha:
        <input type="password" className="pokemon" value={this.state.password} onChange={this.handleChangePassword} /> 
        </label>

        <input type="submit" className="digimon" value="Sign Up" />
        </form>
      );
    }
  }

export default Login;  